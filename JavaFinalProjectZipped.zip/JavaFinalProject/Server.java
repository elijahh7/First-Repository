import java.io.*;
import java.net.*;
import java.util.List;

public class Server {
    public static void main(String[] args) {
        int port = 10004; //Port Number
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                     ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {

                    //System.out.println("Client connected: " + clientSocket.getInetAddress());

                    String searchString = in.readUTF().trim();
                    //System.out.println("Search string: " + searchString);

                    int lineNumber = Integer.parseInt(searchString);

                    LineSearcher lineSearcher = new LineSearcher("C:\\Users\\purpl\\Downloads\\hamlet.txt");
                    List<String> linesAround = lineSearcher.getLinesAround(lineNumber);

                    out.writeObject(linesAround);
                    out.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}