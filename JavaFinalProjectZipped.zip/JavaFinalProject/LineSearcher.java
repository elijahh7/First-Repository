import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class LineSearcher {
    private List<String> lines;

    public LineSearcher(String filePath) {
        try {
            lines = Files.readAllLines(Path.of(filePath));
        } catch (IOException e) {
            e.printStackTrace();
            lines = new ArrayList<>();
        }
    }

    public List<String> getLinesAround(int lineNumber) {
        List<String> result = new ArrayList<>();

        if (lineNumber < 0 || lineNumber >= lines.size()) {
            System.err.println("Invalid line number");
            return result;
        }

        int start = Math.max(0, lineNumber - 2);
        int end = Math.min(lines.size() - 1, lineNumber + 2);

        for (int i = start; i <= end; i++) {
            result.add(lines.get(i));
        }

        return result;
    }

    public static void main(String[] args) {
        LineSearcher lineSearcher = new LineSearcher("C:\\Users\\purpl\\Downloads\\hamlet.txt");
        int lineNumber = 1000;
        List<String> linesAround = lineSearcher.getLinesAround(lineNumber);

        System.out.println("Lines around line number " + lineNumber + ":");
        for (String line : linesAround) {
            System.out.println(line);
        }
    }
}