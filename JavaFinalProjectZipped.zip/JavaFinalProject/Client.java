import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class Client {
    private JFrame frame;
    private JTextField textField;
    private JButton searchButton;
    //private JList<String> resultList;
    public DefaultListModel<String> listModel;
    public JLabel label;
    //public JLabel label;
    private JList<String> listBox;
    //private JLabel statusLabel;
    //private JLabel shutdownHint;

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Client() {
        frame = new JFrame("Line Searcher");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        textField = new JTextField(15);
        searchButton = new JButton("Search lines");
        listModel = new DefaultListModel<>();
        //resultList = new JList<>(listModel);
        listBox = new JList<>(listModel);
        label = new JLabel("Enter shutdown to exit.");
        //statusLabel = new JLabel("Results");
        //shutdownHint = new JLabel("Enter shutdown to exit.");

        JPanel panel = new JPanel();
        panel.add(textField);
        panel.add(searchButton);

        frame.add(panel, BorderLayout.NORTH);

        JPanel resultPanel = new JPanel(new GridLayout(1, 2));
        //resultPanel.add(new JScrollPane(resultList));
        resultPanel.add(new JScrollPane(listBox));
        resultPanel.add(label);
        //resultPanel.add(statusLabel);
        //resultPanel.add(shutdownHint);

        frame.add(resultPanel, BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //searchButton.setEnabled(false);
                listModel.clear();
                //label.setText("Searching...");

                String searchString = textField.getText().trim();

                try {
                    socket = new Socket("127.0.0.1", 10004); // Server and port
                    out = new ObjectOutputStream(socket.getOutputStream());
                    in = new ObjectInputStream(socket.getInputStream());

                    if (searchString.equalsIgnoreCase("shutdown")) {
                        // Shutdown
                        out.writeUTF("shutdown");
                        out.flush();
                        System.out.println("Shutting Down...\n");
                        System.exit(0);
                        //System.out.println("Shutdown");

                    } else {
                        out.writeUTF(searchString + "\n");
                        out.flush();

                        List<String> linesAround = (List<String>) in.readObject();

                        for (String line : linesAround) {
                            listModel.addElement("Line:" + line);
                            //System.out.println("Enter shutdown to exit.");
                        }


                        label.setText("Selected Lines");
                    }
                } catch (IOException | ClassNotFoundException ex) {
                    ex.printStackTrace();
                    label.setText("Error: " + ex.getMessage());
                } finally {
                    try {
                        if (socket != null) socket.close();
                        if (in != null) in.close();
                        if (out != null) out.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        frame.setSize(600, 300);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Client());

    }
}